This example demonstrates a clean Project Change Manager execution.
To run it, execute pcm.sh with bin as the working directory.
You may need to enable execute permissions on pcm.sh (e.g. using chmod 744 pcm.sh).
You may review the log files in the log directory, and the changelog database in the installs directory.