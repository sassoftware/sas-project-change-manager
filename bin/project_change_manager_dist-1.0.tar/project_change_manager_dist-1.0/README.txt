This is the readme file for Project Change Manager 1.0, a SAS management tool for SAS assets.

You can find a copy of the Apache License 2.0 in the file LICENSE of the Project Change Manager distribution.

For documentation, see the root README.md from the git repository where this distribution was downloaded.