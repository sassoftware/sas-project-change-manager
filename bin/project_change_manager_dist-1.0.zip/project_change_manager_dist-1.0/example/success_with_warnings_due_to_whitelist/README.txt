This example demonstrates a that there are certain specific warnings that are ignored by Project Change Manager and won't fail changelog execution. 

To run through the example, execute pcm.sh with bin as the working directory.
You may need to enable execute permissions on pcm.sh (e.g. using chmod 744 pcm.sh).
This will result in a success.
You may review the log files in the log directory.  Note that for some changeset logs there are errors, but they still execute successfully.